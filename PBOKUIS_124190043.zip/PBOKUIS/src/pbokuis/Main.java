/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbokuis;
import java.util.Scanner;
/**
 *
 * @author Administator
 */
public class Main {
        public static void main(String[] args){
                
                        Scanner InputNIM = new Scanner(System.in);
                        Scanner InputNama = new Scanner(System.in);
                        Scanner InputTesTulis = new Scanner(System.in);
                        Scanner InputTesCoding = new Scanner(System.in);
                        Scanner InputTesWawancara = new Scanner(System.in);
                        Scanner Temp = new Scanner(System.in);
                        
             
                         System.out.println("1.Android Development\n2.Web Development\n Pilih : ");
                               int PilihanSeleksi = Temp.nextInt();
               
                     System.out.println("Masukkan NIM : ");
                        String NIM = InputNIM.nextLine();
                     System.out.println("Masukkan Nama : ");
                        String Nama = InputNama.nextLine();
                     System.out.println("Masukkan Nilai Uji Tulis : ");
                        int TesTulis = InputTesTulis.nextInt();
                     System.out.println("Masukkan Nilai Uji Coding : ");
                        int TesCoding = InputTesCoding.nextInt();
                     System.out.println("Masukkan Nilai Uji Wawancara : ");
                        int TesWawancara = InputTesWawancara.nextInt();
        
                int PilihanMenu ;
            do{  
                  System.out.println("Menu\n1.Edit\n2.Tampil\n3.Exit \nPilih :");
                        PilihanMenu = Temp.nextInt();
                        
                          SeleksiWeb Web1 = new SeleksiWeb(NIM,Nama,TesTulis,TesCoding,TesWawancara);
                          SeleksiAndroid Android1 = new SeleksiAndroid(NIM,Nama,TesTulis,TesCoding,TesWawancara); 
                            
                        
                switch(PilihanMenu){
                               case 1:
                                         {
                                               System.out.println("Masukkan Nilai Uji Tulis : ");
                                                 TesTulis = InputTesTulis.nextInt();
                                               System.out.println("Masukkan Nilai Uji Coding : ");
                                                  TesCoding = InputTesCoding.nextInt();
                                               System.out.println("Masukkan Nilai Uji Wawancara : ");
                                                  TesWawancara = InputTesWawancara.nextInt(); 
                                                  
                                                Web1.Edit(TesTulis, TesCoding, TesWawancara);
                                                Android1.Edit(TesTulis, TesCoding, TesWawancara);     
                                         }
                               case 2:
                                        {
                                            switch(PilihanSeleksi)
                                            {
                                                case 1: Android1.Check();
                                                case 2: Web1.Check();
                                            } 
                                         }
                               case 3:
                                            {
                                                return;
                                            }
                           }
        }
    while(PilihanMenu!=3);
    }
}
