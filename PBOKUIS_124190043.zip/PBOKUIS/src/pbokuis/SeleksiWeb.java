/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbokuis;

/**
 *
 * @author Administator
 */
public class SeleksiWeb extends Seleksi
{
     SeleksiWeb(String NIM,String Nama,float TesTulis,float TesCoding,float TesWawancara)
   {
      this.NIM = NIM;
      this.Nama = Nama;
      this.TesTulis = TesTulis;
      this.TesCoding = TesCoding;
      this.TesWawancara = TesWawancara;           
   }
     
     
     
       public void Check()
   {
       if(((this.TesTulis*(0.40))+(this.TesCoding*(0.35)+(this.TesWawancara)*(0.25)))>=85)
        {
           System.out.println("LULUS");
        }
       else
       {
           System.out.println("GAGAL");
       }
    }
}
