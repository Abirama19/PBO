/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swingbalok;

/**
 *
 * @author Administrator
 */
public class PersegiPanjang implements MenghitungBidang {
    protected double panjang;
    protected double lebar;

public PersegiPanjang(double panjang, double lebar)
{
    this.panjang = panjang;
    this.lebar = lebar;
    
}

@Override
public double luas()
{
   return (this.panjang*this.lebar);
}

@Override
public double keliling()
{
    return (2*(this.panjang+this.lebar));
}

    double Luas() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    double Kel() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}